<div class="collapse navbar-collapse">
						<div class="navbar-brand">ERM SYSTEMS</div>
    
    
    
    
    <ul class="nav navbar-nav navbar-right">
							
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">
									<i class="material-icons">person</i>
									
									<p class="hidden-lg hidden-md">Notifications</p>
								</a>
								<ul class="dropdown-menu">
									<li><a href="Update_Profile.php">Edit Profile</a></li>
									<li><a href="changepasswd.php">Change Password</a></li>
									<li><a href="../../login/logout.php">Logout</a></li>
								</ul>
							</li>
						
						</ul>

						
					</div>