<?php
if($_POST["msg"] == "Akshat")
        echo "Here i am ...";
else if($_POST["msg"] == "Yash")
        echo "Gandu haii ...";
else
    echo "Learning new things" .$_POST["id"]."  ";
?>
